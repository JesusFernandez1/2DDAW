$(document).ready(function () {
    $.ajax({
        url : 'damelibro.php',
        type : 'GET',
        dataType : 'text',
        success : function(datos) {
            datos = datos.substring(0, datos.length - 1);
           console.log(datos);
           var datos2=datos.split(',')
           console.log(datos2);
           var libros='<table><tr><th>idlibro</td><td>Titulo</td><td>Autor</td><td>Editora</td><td>Paginas</td><td>Anios</td>'
           $.each(datos, function (idx, elem) {

            if (idx%6==0) {
                
            }
            
           })
        $('#contenido').html(libros);
        },
        error : function(xhr, status) {
            alert('Disculpe, existió un problema');
        },
        complete : function(xhr, status) {
            //alert('Petición realizada');
        }
    });
})
